# FloorPlanner → Chief Architect X17 Export (`fp2dxf`)

Converts a FloorPlanner **v5 design JSON** into per-level **DXF R12** files
purpose-built for Chief Architect X17's **CAD to Walls** importer, so a
FloorPlanner design becomes *native* Chief walls, doors, windows, and
railings — the starting point for an architect-capable drawing set.

This pipeline was validated end-to-end against Chief Architect Premier X17
on 2026-08-17 (two-storey test plan; screenshots below are from that
session). Doors, windows, rails, hinge handedness, per-level export, and
multi-floor stacking all confirmed working.

```
FloorPlanner v5 JSON ──fp2dxf──▶ <level>.dxf + <level>.openings.json
                                        │
                                        ▼   (per floor, in Chief)
                     Import Drawing wizard ▶ CAD > CAD to Walls
                                        │
                                        ▼
                    native Chief walls / doors / windows / rails
```

---

## 1. Integration task for FloorPlanner (what to build)

Add a menu item: **File ▸ Export ▸ Chief Architect (DXF)…**

Behaviour:

1. Prompt for an output directory (QFileDialog.getExistingDirectory).
2. Serialize the current document to the v5 dict (the same structure
   written by Save) and call `fp2dxf.convert()` on it directly — the
   module is **pure stdlib** (no ezdxf, no dependencies) and exposes a
   callable API in addition to its CLI:

   ```python
   from fp2dxf import convert, DEFAULT_THICKNESS

   written = convert(
       doc,                    # the v5 design dict
       outdir,                 # pathlib.Path
       only_levels=None,       # or ["L1"]; also unlocks site levels
       thickness_overrides={}  # {"exterior": 6.5, ...}
   )
   ```

3. Emit one `<level_id>.dxf` **plus** one `<level_id>.openings.json`
   sidecar per storey level. `site` levels are skipped unless explicitly
   requested via `only_levels`.
4. Show a completion summary listing files written and any warnings
   (`Ctx.warnings` collects them: opening overruns, overlapping
   openings, zero-length walls).

### Required config alignment (the one real integration decision)

`DEFAULT_THICKNESS` in `fp2dxf.py` maps wall `type` → assembly inches
when a wall has no `thickness_in` override:

| type      | inches | notes                                            |
|-----------|-------:|--------------------------------------------------|
| exterior  | 6.5    | pairs with Chief stock **Siding-6** (6 7/16")     |
| interior  | 4.5    | pairs with Chief stock **Interior-4** (exact)     |
| partition | 3.5    | pair with an Interior-3½ type if converted        |
| railing   | 3.0    | widened from 1.5 so Chief's rail types match      |
| fence / hedge / retaining | — | reference layers only, never converted |

**This table must agree with FloorPlanner's own per-type standards.**
Wire it to FloorPlanner's config rather than leaving the module
constants authoritative. Chief matches a line-pair spacing to a wall
type within **±1 inch** (see screenshot 09), so exactness beyond that
is not required — agreement is.

### Non-goals

Do not attempt roofs, stairs, cabinets, or furnishings in the DXF.
The division of labour is: FloorPlanner owns plan topology; Chief owns
construction build-up (floor platforms, roof, framing). Vertical data
that must survive (window sill/head, door type, hinge, swing) rides in
the sidecar + on-plan NOTES tags and is applied in Chief during QC.

---

## 2. What the converter emits (design rationale)

* **Coordinates.** FloorPlanner is plan-inches, x-right, **y-down**
  (Qt scene). DXF is y-up, so every y is negated. The plan therefore
  lands in negative-y in Chief — harmless; **do not drag the imported
  CAD before converting** (breaks multi-floor stacking).
* **Walls** are their two *face lines* (centerline ± t/2), square-capped
  at vertex projections. The schema's shared-vertex topology guarantees
  wall ends coincide, and Chief auto-joins converted walls at coincident
  ends, so miters are unnecessary.
* **Layers.** Everything carries an **`FP-` prefix** so imported layers
  can never case-insensitively merge with Chief's native `Doors` /
  `Windows` layers (this merge caused real ambiguity in testing):
  `FP-WALLS`, `FP-RAILS`, `FP-DOORS`, `FP-WINDOWS` (convertible);
  `FP-ROOM-LABELS` (black text), `FP-NOTES` (magenta QC tags);
  `FP-X-CONCEPT`, `FP-X-OPEN-EDGE`, `FP-X-FENCE`, `FP-X-HEDGE`,
  `FP-X-RETAINING` (reference only — never assigned in CAD to Walls).
* **Doors need symbols, not just gaps.** Chief classifies openings by
  conventional drawing symbol. Bare parallel gap lines are read as a
  *window* (screenshot 10 shows both doors arriving as `2640DH`
  double-hung windows on the first attempt). The fix, now implemented:
  hinged doors/gates emit a **leaf line + 90° swing arc** from the
  schema's `hinge` / `swings_toward` (defaulting to `v1`/`left` when
  absent, so classification never fails); sliders emit two overlapping
  half-width panels. Windows remain gap-spanning lines — the
  conventional symbol — and classify correctly.
* **Openings** break both wall face lines at their computed stations.
  Size comes from the WWHH/WWWHH/WWWHHH code; position from the
  `anchor` (`v1`/`v2` = offset to near edge from that end; `center` =
  centre offset from wall midpoint).
* **Concept quarantine.** Walls whose `left`/`right` serve only
  `category:"concept"` rooms go to `FP-X-CONCEPT` and are never
  converted — matching FloorPlanner's semantics that concept rooms
  aren't part of the plan.
* **Open edges** (`wall: null` in a room outline) draw dashed on
  `FP-X-OPEN-EDGE`; in Chief, trace an **Invisible wall** over them so
  the room encloses (Chief requires a wall, even invisible, to bound a
  room).
* **Sidecar** `<level>.openings.json`: per opening id — wall, kind,
  code, station span (inches from v1), sill/head, door_type, hinge,
  swing. Source of truth for the Chief-side QC pass.

---

## 3. Verified Chief Architect X17 import workflow

Run **once per level**, on the matching Chief floor. Use a fresh plan
for the first import.

### 3.1 File ▸ Import ▸ Import Drawing

![Import Drawing dialog](screenshots/01-import-drawing-dialog.png)

* **Show Import Assistant: ON** · Show For Each File: off
* **Create CAD Blocks: OFF** ← critical; blocks hide the individual
  lines from CAD to Walls

### 3.2 Import Assistant — entity handling

![Entity handling](screenshots/02-import-assistant-entities.png)

* Convert lines with shared end points into **Polylines: OFF, Boxes:
  OFF** ← critical; wall faces share endpoints at every corner by
  construction and must stay discrete LINEs
* CAD blocks option: irrelevant (file contains none) · Hatch: off

### 3.3 Select Layers

![Select layers](screenshots/03-select-layers.png)

* Leave **all layers checked**; leave the *Convert To* column **empty**
  (it is for terrain elevation data only)

### 3.4 Layer Mapping

![Layer mapping](screenshots/04-layer-mapping.png)

* Select **“Chief Architect layers by name”** with **“Import all layer
  attributes”** — this preserves the FP-* layers, colours, and
  linetypes. (The default “single layer” flattens everything: wrong.)

### 3.5 Drawing Unit

![Drawing unit](screenshots/05-drawing-unit.png)

* Unit: **in**, drawing is 1:1. Dimension-line options are moot (the
  file contains none).

After Finish, the drawing appears as coloured line work
(black walls, red doors, blue windows, cyan rails):

![Imported CAD](screenshots/06-imported-cad-plan-view.png)

### 3.6 CAD ▸ CAD to Walls… (Ctrl+F3)

![CAD menu](screenshots/07-cad-menu-cad-to-walls.png)

The layer dropdowns list native and imported layers together — pick the
**FP-** entries only:

![Layer dropdown](screenshots/08-convert-dialog-layer-dropdown.png)

| Slot         | Layer      |
|--------------|-----------|
| Wall Layer   | FP-WALLS  |
| Window Layer | FP-WINDOWS|
| Door Layer   | FP-DOORS  |
| Rail Layer   | FP-RAILS  |

Set Wall Types: **Wall Type 1 = Siding-6**, **Wall Type 2 =
Interior-4** (±1" spacing match). Never assign any `FP-X-*` layer.

For the record, the first-session dialog (below) used the merged native
`Windows`/`Doors` layers — with the FP- prefix this ambiguity no longer
exists:

![First-run dialog](screenshots/09-convert-dialog-first-run.png)

### 3.7 Result

First-attempt failure mode that motivated the door symbols — both doors
arrived as `2640DH` windows (correct width/station, wrong class):

![Doors as windows](screenshots/10-first-run-doors-as-windows.png)

Converted plan (walls, rooms, auto-dimensions, auto roof) and 3D:

![Converted plan](screenshots/11-converted-plan-floor1.png)
![3D](screenshots/12-3d-view.png)

Note: Chief's auto dimensions measure to its own framing conventions
and will not literally reproduce sidecar stations; the DXF geometry is
exact. The dashed green perimeter + diagonals are Chief's auto hip
roof (disable via Auto Rebuild Roofs if unwanted during QC).

### 3.8 Additional floors

![Build Floor menu](screenshots/13-build-floor-menu.png)

**Build ▸ Floor ▸ Build New Floor…** → choose **“Derive new 2nd floor
plan from the 1st floor plan”**, accept the floor defaults dialog
(Chief's platform build-up; *Finished Ceiling* is the field to true up
against the level's `height_in` if exact match is wanted):

![2nd floor defaults](screenshots/14-2nd-floor-defaults.png)

Delete the derived placeholder walls, then on Floor 2 import
`L2.dxf` with identical settings and re-run CAD to Walls. Because all
levels share the FloorPlanner origin, floors stack exactly — verify
with the Reference Floor toggle:

![Floor 2 converted](screenshots/15-floor2-converted.png)

### 3.9 QC + cleanup

1. Apply sidecar data Chief can't take from geometry: window
   **sill/head**, slider **door_type**, verify hinge/swing (the magenta
   `FP-NOTES` tags carry the same data on-plan).
2. Trace **Invisible walls** over `FP-X-OPEN-EDGE` lines to enclose
   open-edged rooms.
3. **Edit ▸ Delete Objects** → scope All Floors → check the **CAD**
   group but **uncheck Dimensions, Automatic and Dimensions, Manual**
   (those are live Chief objects, not import residue) → Delete.

![Delete Objects](screenshots/16-delete-objects-cleanup.png)

CAD to Walls copies rather than consumes, so this final sweep removes
the entire imported underlay, leaving a pure native Chief model.

---

## 4. Package contents

| Path | Purpose |
|------|---------|
| `fp2dxf.py` | The converter. Pure stdlib, CLI + `convert()` API. |
| `sample/design-schema_v5.json` | FloorPlanner v5 JSON Schema (source of truth for input). |
| `sample/sample_design.json` | Two-storey test design exercising doors (hinged + slider), windows (v1/center anchors), railing + gate, open edge, concept room. |
| `sample/L1.dxf`, `sample/L2.dxf` | Generated output for the sample (the files imported in the screenshots, current layer/colour scheme). |
| `sample/*.openings.json` | Sidecars for the sample levels. |
| `screenshots/` | The verified workflow, in order (01–16). |

## 5. Known limitations / future work

* `cased` / `pass_through` openings ride `FP-DOORS` with a default door
  symbol; convert to Doorway type during QC (kind is in the tag/sidecar).
* Wall type carries only via thickness matching; multi-layer assembly
  definitions are set in Chief per type, once.
* Gate/door with no `hinge`/`swing` gets defaulted handedness
  (`v1`/`left`) purely for classification — fix handedness in QC.
* Furnishings, reference images, and dimension annotations are not
  exported (deliberate).
* Reverse direction (Chief DXF export → FloorPlanner JSON) is designed
  but not yet implemented; requires a Chief-exported DXF sample to tune
  the wall-pairing pass. Round-trip harness (JSON → Chief → JSON′ diff)
  is the intended regression test once it exists.
